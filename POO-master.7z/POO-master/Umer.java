import java.util.TreeMap;

public class Umer{
   
private TreeMap<String,Utilizador> utilizadores;
private TreeMap<String,Viatura> taxis;
private Utilizador userlogin;

public Umer(){
    this.utilizadores = new TreeMap<String,Utilizador>();
    this.taxis = new TreeMap<String, Viatura>();
    this.userlogin = null;
}


public boolean adicionaUti(Utilizador u){
    
    
}

public boolean login(String email, String password){
    
    
}

public boolean insereViatura(Viatura v){
    
}

public Viagem soliciViagem(Posicao i, Posicao f, Viatura v){
    
}

public double classifMotorista(Utilizador u, double classi){
    
}


    
    
}
